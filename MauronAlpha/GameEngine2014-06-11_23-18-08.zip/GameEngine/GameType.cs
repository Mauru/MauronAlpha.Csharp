﻿using MauronAlpha;
namespace MauronAlpha.GameEngine {
    public class GameType:MauronAlpha.ProjectType {
    }
}
