﻿using MauronAlpha.GameEngine;

namespace MauronAlpha.GameEngine.GameTypes {
    public class GameType_Generic:MauronAlpha.GameEngine.GameType {}
}
