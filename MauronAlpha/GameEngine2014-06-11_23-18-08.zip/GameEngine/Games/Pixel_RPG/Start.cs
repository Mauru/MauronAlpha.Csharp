﻿namespace MauronAlpha.GameEngine.Games.Pixel_RPG {
    public class Start {}
}
